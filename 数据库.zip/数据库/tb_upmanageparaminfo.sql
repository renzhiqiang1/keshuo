/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 12:34:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_upmanageparaminfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_upmanageparaminfo`;
CREATE TABLE `tb_upmanageparaminfo`  (
  `serial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '主键',
  `upserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游主键',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '参数名称',
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '参数值',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `createuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_upmanageparaminfo
-- ----------------------------
INSERT INTO `tb_upmanageparaminfo` VALUES ('11ec5bea5de911eb9986c85b76225b92', 'DFF19255321141D4BF318052599622A8', '2', '2', '2021-01-24 10:08:37', '111');
INSERT INTO `tb_upmanageparaminfo` VALUES ('946826f85df511eb9986c85b76225b92', 'AAB0ECEE3A8E4DE99793C383B9661EAA', '1', '11', '2021-01-24 11:38:10', '111');
INSERT INTO `tb_upmanageparaminfo` VALUES ('946b3bc55df511eb9986c85b76225b92', 'AAB0ECEE3A8E4DE99793C383B9661EAA', '2', '22', '2021-01-24 11:38:10', '111');

SET FOREIGN_KEY_CHECKS = 1;
