/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 02/01/2021 18:57:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_resultinfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_resultinfo`;
CREATE TABLE `tb_resultinfo`  (
  `serial` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `upserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游主键',
  `createtime` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `result` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '反馈结果',
  `downip` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '下游主键',
  PRIMARY KEY (`serial`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '反馈结果存储表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_resultinfo
-- ----------------------------
INSERT INTO `tb_resultinfo` VALUES ('0ef20319442211eb8e23c85b76225b92', NULL, '2020-12-22 14:51:03', NULL, NULL);
INSERT INTO `tb_resultinfo` VALUES ('1', '192.168.', NULL, NULL, NULL);
INSERT INTO `tb_resultinfo` VALUES ('8b9f21f4442211eb8e23c85b76225b92', '1', '2020-12-22 14:54:32', '{\"code\": 1000001,\"success\": false,\"message\": \"登录过期，请重新登录\"}', '127.0.0.1');
INSERT INTO `tb_resultinfo` VALUES ('c90bba96442211eb8e23c85b76225b92', '1', '2020-12-22 14:56:15', '{\"code\": 1000001,\"success\": false,\"message\": \"登录过期，请重新登录\"}', '127.0.0.1');
INSERT INTO `tb_resultinfo` VALUES ('e7c8c1ff442211eb8e23c85b76225b92', '1', '2020-12-22 14:57:07', '{\"code\": 1000001,\"success\": false,\"message\": \"登录过期，请重新登录\"}', '127.0.0.1');

SET FOREIGN_KEY_CHECKS = 1;
