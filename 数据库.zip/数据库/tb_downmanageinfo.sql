/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 12:32:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_downmanageinfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_downmanageinfo`;
CREATE TABLE `tb_downmanageinfo`  (
  `serial` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `createuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `updatetime` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `updateuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `remark` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态 0 无效 1 有效',
  `percent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游反馈按照百分比给下游进行反馈(如：20 按照结果的百分之20进行反馈) 默认为空反馈百分百',
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '下游名称',
  PRIMARY KEY (`serial`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '下游信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_downmanageinfo
-- ----------------------------
INSERT INTO `tb_downmanageinfo` VALUES ('ae26e3825df611eb9986c85b76225b11', '2021-01-24 12:04:39', '111', '2021-01-24 12:01:39', '000', '000', '1', '10', '测试1');
INSERT INTO `tb_downmanageinfo` VALUES ('ae26e3825df611eb9986c85b76225b92', '2021-01-24 12:04:39', '111', '2021-01-24 12:01:39', '000', '000', '1', '10', '测试1');

SET FOREIGN_KEY_CHECKS = 1;
