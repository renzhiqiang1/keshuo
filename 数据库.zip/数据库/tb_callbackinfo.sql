/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 21/01/2021 01:16:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_callbackinfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_callbackinfo`;
CREATE TABLE `tb_callbackinfo`  (
  `serial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createtime` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `callback` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_callbackinfo
-- ----------------------------
INSERT INTO `tb_callbackinfo` VALUES ('0c9eb0d55b4311eb9986c85b76225b92', '2021-01-21 01:15:09', '{offer_id=a}');

SET FOREIGN_KEY_CHECKS = 1;
