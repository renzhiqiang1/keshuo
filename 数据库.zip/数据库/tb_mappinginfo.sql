/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 24/01/2021 12:34:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_mappinginfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_mappinginfo`;
CREATE TABLE `tb_mappinginfo`  (
  `serial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '生成的地址',
  `upserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游主键',
  `downserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '下游主键',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `createuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '0无效 1 有效',
  `updatetime` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `updateuser` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_mappinginfo
-- ----------------------------
INSERT INTO `tb_mappinginfo` VALUES ('48E0DBF9142344F4B31952AEE00E4036', 'http://ks.letianaso.com/inter/redirect?2=2&private=48E0DBF9142344F4B31952AEE00E4036', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 12:28:06', '1', '1', '2021-01-24 12:01:06', '8888');
INSERT INTO `tb_mappinginfo` VALUES ('FD645388C3CE4F65A61DFBD01FC4E262', 'http://ks.letianaso.com/inter/redirect?2=2&private=FD645388C3CE4F65A61DFBD01FC4E262', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:24:36', '1', '1', NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('5656383688E54E878DAE5C85DBFFCF67', 'http://ks.letianaso.com/inter/redirect?2=2&private=5656383688E54E878DAE5C85DBFFCF67', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:26:26', '1', '1', NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('6520613BBE9045EC86A16C11F219AD5C', 'http://ks.letianaso.com/inter/redirect?private=6520613BBE9045EC86A16C11F219AD5C', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 12:28:06', '1', '1', '2021-01-24 12:01:06', '8888');
INSERT INTO `tb_mappinginfo` VALUES ('C1B73A267E9C484885E87CF425BFA046', 'http://ks.letianaso.com/inter/redirect?2=2&private=C1B73A267E9C484885E87CF425BFA046', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:28:21', '1', '1', NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('EEBCA09D49C0474DA11FADF6B265B575', 'http://ks.letianaso.com/inter/redirect?private=EEBCA09D49C0474DA11FADF6B265B575', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:31:23', '1', '1', NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('52534550F466487794D33A01C20572CE', 'http://ks.letianaso.com/inter/redirect?2=2&private=52534550F466487794D33A01C20572CE', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:31:59', '1', '1', NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('7E612F582A5B49E9A4F1E732E77D2AD3', 'http://ks.letianaso.com/inter/redirect?2=2&private=7E612F582A5B49E9A4F1E732E77D2AD3', 'DFF19255321141D4BF318052599622A8', '1', '2021-01-24 11:31:59', '1', '1', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
