/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 05/03/2021 16:30:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_downmappinginfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_downmappinginfo`;
CREATE TABLE `tb_downmappinginfo`  (
  `serial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '主键',
  `mappingserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'tb_mappinginfo表中主键',
  `pars` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '参数',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `idfa` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '下游参数的idfa',
  `callback` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '下游参数反馈接口地址'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_downmappinginfo
-- ----------------------------
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269261', '99146025033269260', '{private=99146025033269260, callback=1111}', '2021-03-05 14:43:51', NULL, '1111');
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269262', '99146025033269260', '{private=99146025033269260, callback=22222}', '2021-03-05 14:50:55', NULL, '22222');
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269263', '99146025033269260', '{private=99146025033269260, idfa=1, callback=1111}', '2021-03-05 14:56:17', '1', '1111');
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269264', '99146025033269260', '{private=99146025033269260, callback=1111}', '2021-03-05 15:07:58', NULL, '1111');
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269265', '99146025033269260', '{private=99146025033269260, callback=http://ks.letianaso.com/api/interface/saveCallBackInfo}', '2021-03-05 15:09:28', NULL, 'http://ks.letianaso.com/api/interface/saveCallBackInfo');
INSERT INTO `tb_downmappinginfo` VALUES ('99146025033269267', '99146025033269266', '{private=99146025033269266, idfa=idfa, callback=88888}', '2021-03-05 16:21:46', 'idfa', '88888');

SET FOREIGN_KEY_CHECKS = 1;
