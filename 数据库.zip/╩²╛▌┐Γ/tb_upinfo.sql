/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 05/03/2021 16:31:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_upinfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_upinfo`;
CREATE TABLE `tb_upinfo`  (
  `serial` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `upip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游地址',
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '0无效 1有效',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `createuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `updatetime` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `updateuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `remark` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '描述',
  `channel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '渠道号标识(上游提供)',
  `adid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '广告标识(产品ID上游提供)',
  `idfa` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '所需传输的数据(设备标识)',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`serial`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '上游信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_upinfo
-- ----------------------------
INSERT INTO `tb_upinfo` VALUES ('1', 'http://192.168.3.131:1101/permission/userController/getUser', '1', '2021-01-19 17:20:40', NULL, '2021-01-19 17:01:59', '0', '111', NULL, NULL, NULL, NULL);
INSERT INTO `tb_upinfo` VALUES ('92236d1c446111eb8e23c85b76225b92', '111', '1', '2021-01-19 17:20:43', '111', '2021-01-19 17:01:59', '0', '111', '111', 'A4431FEADE824F4FE0530100007F071F', '', '');

SET FOREIGN_KEY_CHECKS = 1;
