/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80022
 Source Host           : localhost:3306
 Source Schema         : keshuo

 Target Server Type    : MySQL
 Target Server Version : 80022
 File Encoding         : 65001

 Date: 05/03/2021 16:30:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_mappinginfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_mappinginfo`;
CREATE TABLE `tb_mappinginfo`  (
  `serial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '生成的地址',
  `upserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '上游主键',
  `downserial` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '下游主键',
  `createtime` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `createuser` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '创建人',
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '0无效 1 有效',
  `updatetime` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `updateuser` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `clickrate` int(0) NULL DEFAULT NULL COMMENT '点击量'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_mappinginfo
-- ----------------------------
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269256', 'http://www.baidu.com/&private=99146025033269256&callback={callback}', '99146025033269253', '99146025033269255', '2021-03-04 23:35:49', '1', '1', NULL, NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269257', 'http://www.baidu.com/&private=99146025033269257&callback={callback}', '99146025033269253', '99146025033269255', '2021-03-04 23:44:47', '1', '1', NULL, NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269258', 'http://www.baidu.com/&private=99146025033269258&callback={callback}', '99146025033269253', '99146025033269255', '2021-03-04 23:48:41', '1', '1', NULL, NULL, NULL);
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269259', 'http://ks.letianaso.com/inter/redirect?private=99146025033269259&callback={callback}', '99146025033269253', '99146025033269255', '2021-03-05 00:16:33', '1', '1', NULL, NULL, 12);
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269260', 'http://ks.letianaso.com/inter/redirect?private=99146025033269260&callback={callback}', '99146025033269253', '99146025033269255', '2021-03-05 15:09:28', '1', '1', NULL, NULL, 5);
INSERT INTO `tb_mappinginfo` VALUES ('99146025033269266', 'http://ks.letianaso.com/inter/redirect?private=99146025033269266&callback={callback}&idfa={idfa}', '99146025033269253', '99146025033269255', '2021-03-05 16:21:49', '1', '1', NULL, NULL, 2);

SET FOREIGN_KEY_CHECKS = 1;
